package com.minsait.livraria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Livraria2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
