package tarde1;

public enum TipoStatusEnum {
	
	TRANQUILO, TRISTE, NERVOSO, ESTRESSADO;
	

}
